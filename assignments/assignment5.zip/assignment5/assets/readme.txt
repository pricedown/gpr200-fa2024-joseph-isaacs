All assets used by an assignment must be in their corresponding assets folder.
Types of assets:
-Shader source code
-Textures
-Models
This assets folder will be copied next to your executable when you build.
To access assets from your source, path to "assets/yourassetname.whatever"

